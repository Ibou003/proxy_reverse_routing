/* tslint:disable */
import { Controller, ValidateParam, FieldErrors, ValidateError, TsoaRoute } from 'tsoa';
import { iocContainer } from '../../ioc/ioc';

import { SolutionsController } from './../controllers/SolutionsController';
import { GitLabController } from './../controllers/GitLabController';

const models: TsoaRoute.Models = {
    "Rule": {
        "properties": {
            "id": { "dataType": "string", "required": true },
            "serviceName": { "dataType": "string", "required": true },
        },
    },
    "SolutionRules": {
        "properties": {
            "defaultServiceName": { "dataType": "string", "required": true },
            "crs": { "dataType": "array", "array": { "ref": "Rule" }, "required": true },
            "eds": { "dataType": "array", "array": { "ref": "Rule" }, "required": true },
            "posteOp": { "dataType": "array", "array": { "ref": "Rule" }, "required": true },
        },
    },
    "Solution": {
        "properties": {
            "id": { "dataType": "string", "required": true },
            "label": { "dataType": "string", "required": true },
            "description": { "dataType": "string", "required": true },
            "rules": { "ref": "SolutionRules", "required": true },
        },
    },
    "Message": {
        "properties": {
            "author": { "dataType": "string", "required": true },
            "commit": { "dataType": "string", "required": true },
        },
    },
    "StartingPush": {
        "properties": {
            "branch": { "dataType": "string", "required": true },
            "remote": { "dataType": "string", "required": true },
            "message": { "ref": "Message", "required": true },
        },
    },
};

export function RegisterRoutes(app: any) {
    app.get('/api/solutions',
        function(request: any, response: any, next: any) {
            const args = {
            };

            let validatedArgs: any[] = [];
            try {
                validatedArgs = getValidatedArgs(args, request);
            } catch (err) {
                return next(err);
            }

            const controller = iocContainer.get<SolutionsController>(SolutionsController);

            const promise = controller.getSolutions.apply(controller, validatedArgs);
            promiseHandler(controller, promise, response, next);
        });
    app.get('/api/solutions/:id',
        function(request: any, response: any, next: any) {
            const args = {
                id: { "in": "path", "name": "id", "required": true, "dataType": "string" },
            };

            let validatedArgs: any[] = [];
            try {
                validatedArgs = getValidatedArgs(args, request);
            } catch (err) {
                return next(err);
            }

            const controller = iocContainer.get<SolutionsController>(SolutionsController);

            const promise = controller.getSolution.apply(controller, validatedArgs);
            promiseHandler(controller, promise, response, next);
        });
    app.post('/api/solutions',
        function(request: any, response: any, next: any) {
            const args = {
                solution: { "in": "body", "name": "solution", "required": true, "ref": "Solution" },
            };

            let validatedArgs: any[] = [];
            try {
                validatedArgs = getValidatedArgs(args, request);
            } catch (err) {
                return next(err);
            }

            const controller = iocContainer.get<SolutionsController>(SolutionsController);

            const promise = controller.addSolution.apply(controller, validatedArgs);
            promiseHandler(controller, promise, response, next);
        });
    app.put('/api/solutions/:id',
        function(request: any, response: any, next: any) {
            const args = {
                id: { "in": "path", "name": "id", "required": true, "dataType": "string" },
                solution: { "in": "body", "name": "solution", "required": true, "ref": "Solution" },
            };

            let validatedArgs: any[] = [];
            try {
                validatedArgs = getValidatedArgs(args, request);
            } catch (err) {
                return next(err);
            }

            const controller = iocContainer.get<SolutionsController>(SolutionsController);

            const promise = controller.updateSolution.apply(controller, validatedArgs);
            promiseHandler(controller, promise, response, next);
        });
    app.delete('/api/solutions/:id',
        function(request: any, response: any, next: any) {
            const args = {
                id: { "in": "path", "name": "id", "required": true, "dataType": "string" },
            };

            let validatedArgs: any[] = [];
            try {
                validatedArgs = getValidatedArgs(args, request);
            } catch (err) {
                return next(err);
            }

            const controller = iocContainer.get<SolutionsController>(SolutionsController);

            const promise = controller.removeSolution.apply(controller, validatedArgs);
            promiseHandler(controller, promise, response, next);
        });
    app.post('/api/solutions/download',
        function(request: any, response: any, next: any) {
            const args = {
                solution: { "in": "body", "name": "solution", "required": true, "ref": "Solution" },
            };

            let validatedArgs: any[] = [];
            try {
                validatedArgs = getValidatedArgs(args, request);
            } catch (err) {
                return next(err);
            }

            const controller = iocContainer.get<SolutionsController>(SolutionsController);

            const promise = controller.downLoadFile.apply(controller, validatedArgs);
            promiseHandler(controller, promise, response, next);
        });
    app.get('/api/git/clone',
        function(request: any, response: any, next: any) {
            const args = {
            };

            let validatedArgs: any[] = [];
            try {
                validatedArgs = getValidatedArgs(args, request);
            } catch (err) {
                return next(err);
            }

            const controller = iocContainer.get<GitLabController>(GitLabController);

            const promise = controller.gitLabClone.apply(controller, validatedArgs);
            promiseHandler(controller, promise, response, next);
        });
    app.get('/api/git/add',
        function(request: any, response: any, next: any) {
            const args = {
            };

            let validatedArgs: any[] = [];
            try {
                validatedArgs = getValidatedArgs(args, request);
            } catch (err) {
                return next(err);
            }

            const controller = iocContainer.get<GitLabController>(GitLabController);

            const promise = controller.gitLabAdd.apply(controller, validatedArgs);
            promiseHandler(controller, promise, response, next);
        });
    app.post('/api/git/commit',
        function(request: any, response: any, next: any) {
            const args = {
                message: { "in": "body", "name": "message", "required": true, "ref": "Message" },
            };

            let validatedArgs: any[] = [];
            try {
                validatedArgs = getValidatedArgs(args, request);
            } catch (err) {
                return next(err);
            }

            const controller = iocContainer.get<GitLabController>(GitLabController);

            const promise = controller.gitLabCommit.apply(controller, validatedArgs);
            promiseHandler(controller, promise, response, next);
        });
    app.get('/api/git/checkout/:branch',
        function(request: any, response: any, next: any) {
            const args = {
                branch: { "in": "path", "name": "branch", "required": true, "dataType": "string" },
            };

            let validatedArgs: any[] = [];
            try {
                validatedArgs = getValidatedArgs(args, request);
            } catch (err) {
                return next(err);
            }

            const controller = iocContainer.get<GitLabController>(GitLabController);

            const promise = controller.gitLabCheckout.apply(controller, validatedArgs);
            promiseHandler(controller, promise, response, next);
        });
    app.get('/api/git/pull',
        function(request: any, response: any, next: any) {
            const args = {
            };

            let validatedArgs: any[] = [];
            try {
                validatedArgs = getValidatedArgs(args, request);
            } catch (err) {
                return next(err);
            }

            const controller = iocContainer.get<GitLabController>(GitLabController);

            const promise = controller.gitLabPull.apply(controller, validatedArgs);
            promiseHandler(controller, promise, response, next);
        });
    app.get('/api/git/push',
        function(request: any, response: any, next: any) {
            const args = {
            };

            let validatedArgs: any[] = [];
            try {
                validatedArgs = getValidatedArgs(args, request);
            } catch (err) {
                return next(err);
            }

            const controller = iocContainer.get<GitLabController>(GitLabController);

            const promise = controller.gitLabPush.apply(controller, validatedArgs);
            promiseHandler(controller, promise, response, next);
        });
    app.get('/api/git/branchs',
        function(request: any, response: any, next: any) {
            const args = {
            };

            let validatedArgs: any[] = [];
            try {
                validatedArgs = getValidatedArgs(args, request);
            } catch (err) {
                return next(err);
            }

            const controller = iocContainer.get<GitLabController>(GitLabController);

            const promise = controller.gitLabBranchLocal.apply(controller, validatedArgs);
            promiseHandler(controller, promise, response, next);
        });
    app.post('/api/git/starting',
        function(request: any, response: any, next: any) {
            const args = {
                startingPush: { "in": "body", "name": "startingPush", "required": true, "ref": "StartingPush" },
            };

            let validatedArgs: any[] = [];
            try {
                validatedArgs = getValidatedArgs(args, request);
            } catch (err) {
                return next(err);
            }

            const controller = iocContainer.get<GitLabController>(GitLabController);

            const promise = controller.startingGilabPush.apply(controller, validatedArgs);
            promiseHandler(controller, promise, response, next);
        });


    function promiseHandler(controllerObj: any, promise: any, response: any, next: any) {
        return Promise.resolve(promise)
            .then((data: any) => {
                let statusCode;
                if (controllerObj instanceof Controller) {
                    const controller = controllerObj as Controller
                    const headers = controller.getHeaders();
                    Object.keys(headers).forEach((name: string) => {
                        response.set(name, headers[name]);
                    });

                    statusCode = controller.getStatus();
                }

                if (data) {
                    response.status(200).json(data);
                } else {
                    response.status(statusCode || 204).end();
                }
            }).catch(next);
    }

    function getValidatedArgs(args: any, request: any): any[] {
        const errorFields: FieldErrors = {};
        const values = Object.keys(args).map(function(key) {
            const name = args[key].name;
            switch (args[key].in) {
                case 'request':
                    return request;
                case 'query':
                    return ValidateParam(args[key], request.query[name], models, name, errorFields);
                case 'path':
                    return ValidateParam(args[key], request.params[name], models, name, errorFields);
                case 'header':
                    return ValidateParam(args[key], request.header(name), models, name, errorFields);
                case 'body':
                    return ValidateParam(args[key], request.body, models, name, errorFields);
                case 'body-prop':
                    return ValidateParam(args[key], request.body[name], models, name, errorFields);
            }
        });

        if (Object.keys(errorFields).length > 0) {
            throw new ValidateError(errorFields, '');
        }
        return values;
    }
}