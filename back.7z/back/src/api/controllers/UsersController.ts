/**
 * Controller for User
 */
import * as Promise from 'bluebird';
import { provideSingleton, inject } from '../../ioc/ioc';
import { Get, Route, Post, Delete, Put, Body, Tags } from 'tsoa';
import { User } from '../models/User';
import { UsersService } from '../services/UsersService';

@Route('users')
@Tags('Users')
@provideSingleton(UsersController)
export class UsersController {

    @inject(UsersService)
    private usersService: UsersService;

    /**
     * Get list of users
     */
    @Get()
    public getUsers(): Promise<User[]> {
        return this.usersService.getUsers();
    }

    /**
     * Get a specific user
     */
    @Get('/{id}')
    public getUser(id: string): Promise<User> {
        return this.usersService.getUser(id);
    }

    /**
     * Add a user
     */
    @Post()
    public addUser(@Body() user: User): Promise<User> {
        return this.usersService.addUser(user);
    }

    /**
     * Update a user
     */
    @Put('/{id}')
    public updateUser(id: string, @Body() user: User): Promise<User> {
        return this.usersService.updateUser(id, user);
    }

    /**
     * Delete a specific user
     */
    @Delete('/{id}')
    public removeUser(id: string): Promise<User> {
        return this.usersService.removeUser(id);
    }
}
