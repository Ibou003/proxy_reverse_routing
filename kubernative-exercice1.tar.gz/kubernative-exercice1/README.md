# Exercice 1

### Avant propos
Vous serez plusieurs formés à travailler sur le même namespace, pensez à spécifier vos noms et labels afin de ne pas vous marcher sur les pieds.

### Etat initial
Dans le répertoire **src**, vous trouverez un fichier **main.py**

### But de l'exercice
Le but de l'exercice est d'installer l'application définie dans le fichier python fourni et de le rendre disponible à l'url :  
https://hello-**{{environement utilisateur}}**.hors-prod.caas.ca-cf.gca

### Marche à suivre
Vous pouvez soit effectuer la mise en place par vous même, soit suivre la procédure mise à disposition dans le fichier [solution.md](solution.md).  
Quoi qu'il en soit, vous aurez besoin des informations suivantes :  
- Pour se connecter à artifactory via docker :  
*cagip-formation-te-docker-scratch-intranet*  
- Merci de déposer votre/vos image(s) dans :  
*cagip-formation-te-docker-scratch-intranet/**{{environement utilisateur}}**/*  
- URL artifactory :  
[https://registry.saas.cagip.gca/](https://registry.saas.cagip.gca/)  
- Pour vous connecter à **kubi** :  
*kubi.devops.managed.cagip.group.gca*  
- namespace de formation :  
*formation-te-development*  

A la fin de l'exercice, merci de penser à nettoyer les objets kube créés sur le namespace de formation.