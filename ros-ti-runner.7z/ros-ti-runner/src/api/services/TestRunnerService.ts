import { provideSingleton } from '../../ioc/ioc';
import * as _ from 'lodash';
import { Promise } from 'bluebird';
import { Service } from './Service';
import { TestSuite, TestSuiteResult, TestStatus, Test, TestResult } from '../models/Test';
import {logger} from '../../common/log/logger';


@provideSingleton(TestRunnerService)
export class TestRunnerService extends Service {

    public runTestSuite(testSuite: TestSuite): Promise<TestSuiteResult> {
        logger.info(`Execution de la test suite: ${testSuite.name}`);

        if (!_.isEmpty(testSuite.description)) {
            logger.info(testSuite.description);
        }

        let testSuiteResult: TestSuiteResult = {
            name: testSuite.name,
            status: TestStatus.PASSED,
            report: {
                testsFailed: 0,
                testsPassed: 0,
                testsSkipped: 0,
                testsTotal: testSuite.tests.length,
                testsResult: []
            }
        };

        // Iterate over test
        if (testSuite.skip) {
            testSuiteResult.status = TestStatus.SKIPPED;
            testSuiteResult.report.testsSkipped = testSuite.tests.length;
            return Promise.resolve(testSuiteResult);
        } else {
            const testsResultPromise = [];
            _.each(testSuite.tests, (test: Test) => {
                const testResultPromise = this.executeTest(test).then((testResult: TestResult) => {
                    switch (testResult.status) {
                        case TestStatus.PASSED:
                            testSuiteResult.report.testsPassed++;
                        break;
                        case TestStatus.FAILED:
                            testSuiteResult.report.testsFailed++;
                        break;
                        default:
                        break;
                    }
                    testSuiteResult.report.testsResult.push(testResult);
                });

                testsResultPromise.push(testResultPromise);
            });
            return Promise.all(testsResultPromise).then(() => {
                testSuiteResult.status = testSuiteResult.report.testsFailed > 0 ? TestStatus.FAILED : TestStatus.PASSED;
                return testSuiteResult;
            });
        }
    }

    public runTestSuites(testSuites: TestSuite[]): Promise<TestSuiteResult[]> {
        const testSuitesPromise = [];

        _.each(testSuites, (testSuite: TestSuite) => {
            testSuitesPromise.push(this.runTestSuite(testSuite));
        });

        return Promise.all(testSuitesPromise).then((testSuitesResults: TestSuiteResult[]) => {
            return testSuitesResults;
        });
    }

    public runTest(test: Test): Promise<TestResult> {
        return this.executeTest(test);
    }

    private executeTest(test: Test): Promise<TestResult> {
        logger.info(`**********  Lancement du test ${test.name}  **********`);
        const testResult: TestResult = {
            name: test.name,
            status: TestStatus.PASSED
        };

        if (test.skip) {
            testResult.status = TestStatus.SKIPPED;
            logger.warn(`Test status: ${testResult.status}`);
            return Promise.resolve(testResult);
        } else {
            const contextHeader = {
                UserContext: JSON.stringify(test.context),
                Cookie: String(test.cookies)
            };

            const additionalHeaders = _.assign(contextHeader, test.request.headers);
            const requestOptions = this.getRequestOptions(test.request.path, test.request.method, test.request.body, additionalHeaders);
            let testStatus: TestStatus = TestStatus.PASSED;
            logger.info(`Execution de la requête: ${test.request.method} - ${test.request.path}`);
            if (test.request.body) {
                logger.info(`Body: ${JSON.stringify(test.request.body)}`);
            }

            logger.info(`Headers: ${JSON.stringify(additionalHeaders)}`);
            return this.rp(requestOptions).then((response) => {
                // Test
                testStatus = _.isEqual(response.body, test.expected.body) &&
                _.isEqual(response.statusCode, test.expected.httpStatus) ? TestStatus.PASSED : TestStatus.FAILED;

                switch (testStatus) {
                    case TestStatus.FAILED:
                        testResult.report = {
                            expected: test.expected,
                            got: {
                                httpStatus: response.statusCode || 'unknown',
                                body: response.body || 'unknown'
                            }
                        };
                    break;
                    default:
                    break;
                }
                testResult.status = testStatus;
                logger.warn(`Test status: ${testResult.status}`);
                return testResult;
            }).catch(err => {
                logger.error(err.message);
                testStatus = _.isEqual(err.statusCode, test.expected.httpStatus) ? TestStatus.PASSED : TestStatus.FAILED;

                switch (testStatus) {
                    case TestStatus.FAILED:
                        testResult.report = {
                            expected: test.expected,
                            got: {
                                httpStatus: err.statusCode || 'unknown',
                                error: err.message
                            }
                        };
                    break;
                    default:
                    break;
                }
                testResult.status = testStatus;
                return testResult;
            });
        }
    }
}
