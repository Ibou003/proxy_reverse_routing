# Liens utiles du wiki CAGIP pour exercice1

### Connexion au cluster et namespace
[https://wiki.sws.group.gca/pages/viewpage.action?pageId=17989674](https://wiki.sws.group.gca/pages/viewpage.action?pageId=17989674)

### Push des images dans Artifactory
[https://wiki.sws.group.gca/display/CCDH/0.+Build%2C+push+et+pull+d%27images+Docker](https://wiki.sws.group.gca/display/CCDH/0.+Build%2C+push+et+pull+d%27images+Docker)

### Documentation Kubernetes
[https://kubernetes.io/docs/](https://kubernetes.io/docs/)