export const environment = {
  production: false,
  API_BASE_PATH: 'https://puc-development.hors-prod.caas.ca-ts.group.gca/ros-bff/api'
};
