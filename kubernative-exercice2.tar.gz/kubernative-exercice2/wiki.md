# Liens utiles du wiki CAGIP pour l'exercice2

### Déployer une application avec kustomize
[https://wiki.sws.group.gca/display/CCDH/5.+Deployer+une+application+dans+Kubernetes+avec+Kustomize](https://wiki.sws.group.gca/display/CCDH/5.+Deployer+une+application+dans+Kubernetes+avec+Kustomize)

### Documentation kubectl - dont une partie pour kustomize
[https://kubectl.docs.kubernetes.io/](https://kubectl.docs.kubernetes.io/)