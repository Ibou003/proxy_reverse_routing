import Server from '../Server';
import 'mocha';
import * as request from 'request';
import { expect } from 'chai';
import constants from '../utils/Constants';
const server = new Server();

describe('loadRules', () => {
    before(done => {
        console.log(server);
        done();
    });
    // je relance le serveur sur le port 8080
    it('label «solution !=ServiceName»', done => {
        request(constants.URLS.MS.ROSE + '/nonService/api/version', (error, response, body) => {
            expect(response.statusCode).to.equal(404);
            done();
        });

    });

    it('label «solution == ServiceName»', done => {
        request(constants.URLS.MS.ROSE + '/crap/api/version', (error, response, body) => {
            expect(response.statusCode).to.equal(200);
            done();
        });
    });
    it('la liste plusieurs occurence ', () => {
        // const authorizationRules = { rules: [{name: 'http://im-app-crap-ihme', type: 'ihm', solution: 'crap', version: 'current'}, {name: 'http://im-app-crap-ihme', type: 'ihm', solution: 'crap', version: 'current'}]};
        // const dataRules = new DataKub(authorizationRules, null);
        // const res: HttpResponseRules =  reverseProxy.loadRequest(requestMock, responseMock, httpRessources, dataRules);
        // expect(res.status).to.equal(409);
    });

    it('la liste contient 0 ou plusieurs  occurence du  label «solution=crap»', () => {
        // const resources =   {};
        // const dataRules = new DataKub(authorizationRulesMock, resources);
        // const res: HttpResponseRules =  reverseProxy.loadRequest(requestMock, responseMock, httpRessources, dataRules);
        // expect(res.status).to.equal(200);
    });

    it('la CR ou EDS ou  poste opérationnel  renseigné dans le header de ma requête est présente dans les règles de routage « solution=CRAP »  ', () => {
        // const resources =   { crap: {
        //     cr: { '87800': 'pilote' },
        //     eds: { '878000020007': 'pilote' },
        //     posteOp: { 'WAZST0020004': 'pilote', '82554455657788885555': 'pilote' }}
        //   };
        // const dataRules = new DataKub(authorizationRulesMock, resources);
        // const res: HttpResponseRules =  reverseProxy.loadRequest(requestMock, responseMock, httpRessources, dataRules);
        // expect(res.status).to.equal(200);
    });

});

after((done) => {
    // server.stop();
    done();
});
