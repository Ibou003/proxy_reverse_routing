# Exercice 6

### Avant propos
Vous serez plusieurs formés à travailler sur le même namespace, pensez à spécifier vos noms et labels afin de ne pas vous marcher sur les pieds.

### Etat initial
Sont disponibles :
- Dans **src** le source de l'application
- **Dockerfile** pour la construction de l'image
- Dans **kustomize**, l'ensemble des fichiers de déploiement de l'application au format kustomize.

### But de l'exercice
Si vous allez voir dans le fichier source, vous pourrez voir que celui-ci a été mis à jour pour remonter un metric ***hello_call*** via l'URL */metrics*  
(Note : pensez à mettre à jour le nom de la metric en ***{{votre nom/trigramme/...}}_hello_call*** pour plus de lisibilité par la suite).  
Le but de cet exercice est de remonter cette metric jusqu'à Prométheus.

### Marche à suivre
Vous aurez besoin pour cet exercice de l'URL de Prométheus :   
[https://prometheus.devops.caas.cagip.group.gca/](https://prometheus.devops.caas.cagip.group.gca/)