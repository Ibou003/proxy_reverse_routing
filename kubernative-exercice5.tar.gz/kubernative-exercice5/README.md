# Exercice 5

### Avant propos
Vous serez plusieurs formés à travailler sur le même namespace, pensez à spécifier vos noms et labels afin de ne pas vous marcher sur les pieds.

### Etat initial
Sont disponibles :
- Dans **src** le source de l'application
- **Dockerfile** pour la construction de l'image
- Dans **kustomize**, l'ensemble des fichiers de déploiement de l'application au format kustomize.

### But de l'exercice
Le but de cet exercice est de créer un secret dans **Vault** et de l'afficher dans l'application.

### Marche à suivre
Pour cet exercice, vous aurez besoin de l'URL de vault :  
[https://vault.saas.cagip.gca/](https://vault.saas.cagip.gca/)  
Et du chemin du projet dans vault :  
*secret/devops/formation_te/k8s/development/*

Lors de la création de votre "catalogue" de secret utilisez votre nom/trigramme/... pour plus de visibilité.