import { EventEmitter, Injectable } from '@angular/core';
import { Router } from '@angular/router';
import * as _ from 'lodash';
import { SecurityService } from '../http-client/api/security.service';
import constants from '../../const';
import { Session } from '../models/security';
import { SharedService } from './shared.service';

@Injectable()
export class AuthService {
    error: any;
    loggedInEvent = new EventEmitter<boolean>();

    constructor(
        private securityService: SecurityService,
        private sharedService: SharedService,
        private router: Router
    ) {}

    get authenticated(): boolean {
        return !_.isNull(this.getSession().accessToken);
    }

    login(redirectTo: string) {
        // Redirect to login
        this.router.navigate([constants.ROUTES.PATHS.LOGIN], { queryParams: { redirectTo } });
    }
    private _setSession(sessionToken: any) {
        // Store oauthToken information in localStorage
        sessionStorage.setItem('access_token', sessionToken);
    }

    getSession() {
        return {
            accessToken: _.isNull(sessionStorage.getItem('access_token')) ? null : sessionStorage.getItem('access_token')
        };
    }
}
