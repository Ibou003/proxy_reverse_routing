import * as Promise from 'bluebird';
import { provideSingleton } from '../../ioc/ioc';
import { Cr } from '../models/Cr';
import * as _ from 'lodash';
import { NotFoundAPIError } from '../../common/Error/NotFoundAPIError';
import { IllegalArgumentError } from '../../common/Error/IllegalArgumentError';

@provideSingleton(CrsService)
export class CrsService {

    private crs: Cr[];

    constructor() {
        this.crs = [];
    }

    public getCrs(): Promise<Cr[]> {
        return this.crs;
    }

    public getCr(id: string): Promise<Cr> {
        const cr: Cr = _.find(this.crs, {id: id});

        if (!_.isEmpty(cr)) {
            return cr;
        } else {
            throw new NotFoundAPIError(`Cr with id ${id} not found`);
        }
    }

    public addCr(cr: Cr): Promise<Cr> {
        // check if cr with id already exists
        const foundCr = _.find(this.crs, {id: cr.id});

        if (!_.isEmpty(foundCr)) {
            throw new IllegalArgumentError(`Cr with id ${cr.id} already exists`);
        } else {
            this.crs.push(cr);
            return cr;
        }
    }

    public updateCr(id: string, cr: Cr): Promise<Cr> {
        // Check if cr with id exists
        const crIndex = _.findIndex(this.crs, {id: id});

        if (crIndex > -1) {
            this.crs[crIndex] = cr;
            return cr;
        } else {
            throw new NotFoundAPIError(`Cr with id ${id} not found`);
        }
    }

    public removeCr(id: string): Promise<Cr> {
        const crRemoved: Cr[] = _.remove(this.crs, (cr) => {
            return cr.id === id;
        });

        return crRemoved.length > 0 ? crRemoved[0] : null ;
    }
}
