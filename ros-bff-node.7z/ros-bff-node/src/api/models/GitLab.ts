export interface Message {
    author: string;
    commit: string;
}
export interface StartingPush {
    branch: string;
    remote: string;
    message: Message;
}
