import {APIError} from './APIError';

export class NotFoundAPIError extends APIError {

    public  constructor(msg: string, previousError?: Error, data?: any) {
        super(msg, previousError, data);
        this.code = '404';
    }
}
