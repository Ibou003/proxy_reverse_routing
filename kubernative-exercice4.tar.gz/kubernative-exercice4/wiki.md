# Liens utiles du wiki CAGIP pour l'exercice4

### Accès à Xray
[https://wiki.sws.group.gca/pages/viewpage.action?pageId=17989934](https://wiki.sws.group.gca/pages/viewpage.action?pageId=17989934)

### API Promote des images vers stabble - pour la production -
[https://wiki.sws.group.gca/pages/viewpage.action?pageId=17995876](https://wiki.sws.group.gca/pages/viewpage.action?pageId=17995876)