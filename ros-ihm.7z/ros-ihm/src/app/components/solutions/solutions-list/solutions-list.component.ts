import {
  Component,
  OnInit
} from '@angular/core';
import { FormGroup, FormControl, Validators, FormArray } from '@angular/forms';
import { SolutionsService } from 'src/app/http-client/api/solutions.service';
import { Solution } from 'src/app/http-client/model/solution';
import { AlertService } from '../../alert/alert.service';

@Component({
  selector: 'app-solutions-list',
  templateUrl: './solutions-list.component.html',
  styleUrls: ['./solutions-list.component.scss']
})
export class SolutionsListComponent implements OnInit {
  solutions: Solution[];
  private selectedSolutionId;
  selectedSolution: Solution;
  editMode = false;
  solutionForm: FormGroup;
  constructor(private solutionsService: SolutionsService, private alertService: AlertService) {
    this.loadingSolutions();
  }

  ngOnInit() {
    this.solutionsService.solutionListChange$.subscribe(data => {
      this.loadingSolutions();
    });
  }
  onSelectedSolution(selectedSolutionId) {
    if (selectedSolutionId !== '' || selectedSolutionId === undefined) {
      this.selectedSolution = null;
      this.selectedSolutionId = selectedSolutionId;
      this.editMode = false;
      this.alertService.clear();
      this.solutionsService.getSolution(this.selectedSolutionId).subscribe((solution: any) => {
        this.selectedSolution = solution;
        this.initForm(this.selectedSolution);
      });
    } else {
      this.selectedSolutionId = null;
      this.selectedSolution = null;
    }
  }

  onAddSolution() {
    this.selectedSolution = null;
    this.alertService.clear();
    this.editMode = true;
    if (this.solutionForm && this.solutionForm.value) {
      this.solutionForm.enable();
    }
    this.initForm(null);
  }

  loadingSolutions() {
    this.solutions = null;
    this.editMode = false;
    this.solutionsService.getSolutionsList().subscribe((solutions: Solution[]) => {
      this.solutions = solutions;
    });
  }

  private initForm(solution) {
    let solutionId = '';
    let solutionLabel = '';
    let solutionDescription = '';
    let solutionRules = new FormGroup({});
    if (solution) {
      solutionId = solution.id;
      solutionLabel = solution.label;
      solutionDescription = solution.description;
    }
    solutionRules = this.rulesForm(this.selectedSolution);
    this.solutionForm = new FormGroup({
      id: new FormControl({ value: solutionId, disabled: !this.editMode }, Validators.required),
      label: new FormControl({ value: solutionLabel, disabled: !this.editMode }, Validators.required),
      description: new FormControl({ value: solutionDescription, disabled: !this.editMode }),
      rules: solutionRules
    });
  }
  addRulesFormArray(name: string) {
    let rulesFormArray = new FormArray([]);
    if (this.selectedSolution && this.selectedSolution.rules[name]) {
      for (const rule of this.selectedSolution.rules[name]) {
        rulesFormArray.push(
          new FormGroup({
            id: new FormControl({ value: rule.id, disabled: !this.editMode }),
            serviceName: new FormControl({ value: rule.serviceName, disabled: !this.editMode })
          })
        );
      }
    }
    return rulesFormArray;
  }

  private rulesForm(solution): FormGroup {
    let rulesForm = new FormGroup({});
    let defaultServiceName = '';
    if (solution && solution.rules) {
      defaultServiceName = solution.rules.defaultServiceName;
    }
    rulesForm = new FormGroup({
      defaultServiceName: new FormControl({ value: defaultServiceName, disabled: !this.editMode }, Validators.required),
      posteOp: this.addRulesFormArray('posteOp'),
      crs: this.addRulesFormArray('crs'),
      eds: this.addRulesFormArray('eds')
    });
    return rulesForm;
  }

}
