# Lien utile du wiki CAGIP pour l'exercice5

### Intégrer un secret Vault - chapitre Secrets - Vault Intégration
[https://wiki.sws.group.gca/pages/viewpage.action?pageId=17989693](https://wiki.sws.group.gca/pages/viewpage.action?pageId=17989693)