/**
 * Controller for Solution
 */
import * as Promise from 'bluebird';
import { provideSingleton, inject } from '../../ioc/ioc';
import { Get, Route, Post, Delete, Put, Body, Tags } from 'tsoa';
import { Solution } from '../models/Solution';
import { SolutionsService } from '../services/SolutionsService';
@Route('solutions')
@Tags('Solutions')
@provideSingleton(SolutionsController)
export class SolutionsController {

    @inject(SolutionsService)
    private solutionsService: SolutionsService;

    /**
     * Get list of solutions
     */
    @Get()
    public getSolutions(): Promise<Solution[]> {
        return this.solutionsService.getSolutions();
    }

    /**
     * Get a specific solution
     */
    @Get('/{id}')
    public getSolution(id: string): Promise<Solution> {
        return this.solutionsService.getSolution(id);
    }

    /**
     * Add a solution
     */
    @Post()
    public addSolution(@Body() solution: Solution): Promise<Solution> {
        return this.solutionsService.addSolution(solution);
    }

    /**
     * Update a solution
     */
    @Put('/{id}')
    public updateSolution(id: string, @Body() solution: Solution): Promise<Solution> {
        return this.solutionsService.updateSolution(id, solution);
    }

    /**
     * Delete a specific solution
     */
    @Delete('/{id}')
    public removeSolution(id: string): Promise<Solution> {
        return this.solutionsService.removeSolution(id);
    }
    @Post('/download')
    public downLoadFile(@Body() solution: Solution): Promise<string> {
        return this.solutionsService.downLoadFile(solution);
    }
}
