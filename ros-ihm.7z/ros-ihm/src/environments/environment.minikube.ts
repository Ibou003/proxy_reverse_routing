export const environment = {
  production: false,
  API_BASE_PATH: 'http://minikube.local/ros-bff/api'
};
