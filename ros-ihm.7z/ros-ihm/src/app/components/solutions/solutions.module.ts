import { NgModule } from '@angular/core';
import { SolutionsRoutingModule } from './solutions-routing.module';
import { SolutionEditComponent } from './solution-edit/solution-edit.component';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RuleEditComponent } from './solution-edit/rule-edit/rule-edit.component';
import { AlertModule } from '../alert/alert.module';
import { SolutionsListComponent } from './solutions-list/solutions-list.component';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    AlertModule,
    ReactiveFormsModule,
    SolutionsRoutingModule,  // Added
  ],
  declarations: [SolutionsListComponent, SolutionEditComponent, RuleEditComponent]
})
export class SolutionsModule { }
