export interface User {
    id?: string;
    lastName: string;
    firstName: string;
}
