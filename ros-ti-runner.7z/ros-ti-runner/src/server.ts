import 'reflect-metadata';
import * as bodyParser from 'body-parser';
import * as cors from 'cors';
import * as express from 'express';
import * as cookieParser from 'cookie-parser';
import * as morgan from 'morgan';
import { APIError } from './common/Error/APIError';
import { RegisterRoutes } from './api/routes/routes';
import { logger } from './common/log/logger';
const app = express();
const options: cors.CorsOptions = {
    credentials: true,
    methods: 'GET,HEAD,OPTIONS,PUT,PATCH,POST,DELETE',
    origin: '*',
    preflightContinue: false
};

require('source-map-support').install();

class Server {

    public static bootstrap(): Server {
        const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 9000;
        logger.info(process.env.NODE_TLS_REJECT_UNAUTHORIZED);
        app.use(cors(options));

        logger.info('env ' + process.env.PORT);
        app.disable('x-powered-by');
        app.use(morgan('dev'));
        app.use(cookieParser());

        logger.info(`Démmarage du ROS Test Runner sur le port ${port} ...`);

        app.use(bodyParser.urlencoded({ extended: true }));
        app.use(bodyParser.json());

        RegisterRoutes(app);
        app.use(function (err: any, req: express.Request, res: express.Response, next: express.NextFunction) {
            let apiErr = null;
            if (err instanceof APIError) {
                apiErr = err;
            } else {
                apiErr = new APIError('internal_error', err);
            }

            err = {
                uid: apiErr.uid,
                message: apiErr.message,
                data: apiErr.data
            };
            res.status(apiErr.code).json(err);
        });

        app.listen(port, '0.0.0.0', () => {
            // tslint:disable-next-line:variable-name
            const node_environment = process.env.NODE_ENV || 'default';
            logger.info('ROS Test Runner démarré !!!');
            logger.info(`Environnement d'exécution: ${node_environment}`);
        });

        process.on('SIGINT', function () {
            logger.log('error', 'Arrêt du serveur');
            process.exit(0);
        });

        return this;
    }
}

let server = Server.bootstrap();
export { server };
