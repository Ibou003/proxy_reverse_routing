export * from './solutions.service';
import { SolutionsService } from './solutions.service';
export * from './security.service';
import { SecurityService } from './security.service';
export const APIS = [SolutionsService, SecurityService];
