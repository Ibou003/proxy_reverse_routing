# Exercice 7

### Avant propos
Vous serez plusieurs formés à travailler sur le même namespace, pensez à spécifier vos noms et labels afin de ne pas vous marcher sur les pieds.

### Etat initial
Sont disponibles :
- Dans **src** le source de l'application
- **Dockerfile** pour la construction de l'image
- Dans **kustomize**, l'ensemble des fichiers de déploiement de l'application au format kustomize.

### Marche à suivre
Dans cet exercice, nous allons découvrir l'observabilité des logs de votre application via ELISA-ELK.

1 Connexion
- Connectez vous à l'url ELISA-ELK avec vos identifiants compte AD
- Utiliser le space Default qui est connecté au namespace formation-te-development

2 Création d'un patern pour récupérer les logs (si il n'existe pas déjà)
- Dans le module Management, dans Kibana, lien Index Patterns
- Cliquer sur le bouton Create Index Patterns
- Dans index pattern, créer le pattern logstash-formation-te-development*

3 Utilisation du pattern pour afficher les logs de votre application
- Dans le module Discover
- Dans la case logstash-*, renseigner le pattern créé précedemment
- Observez vos messages 

4 Exercez vous à utiliser les filtres pour affiner vos recherches

5 Exercez vous à construire des graphes
- Dans le module Vizualize

### Marche à suivre
Vous aurez besoin pour cet exercice de l'URL de ELISA-ELK :   
[https://mutu-logs-k8s.elisa.saas.cagip.group.gca/](https://mutu-logs-k8s.elisa.saas.cagip.group.gca/)
