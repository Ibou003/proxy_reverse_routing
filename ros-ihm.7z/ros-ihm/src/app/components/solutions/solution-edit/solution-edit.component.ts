import {
  Component,
  Input
} from '@angular/core';
import { FormGroup } from '@angular/forms';
import { Solution } from 'src/app/http-client/model/solution';
import { SolutionsService } from 'src/app/http-client';
import { AlertService } from '../../alert/alert.service';
import { GitLabService } from 'src/app/http-client/api/gitlab.service';
import { StartingPush } from 'src/app/http-client/model/GitLab';
@Component({
  selector: 'app-solution-edit',
  templateUrl: './solution-edit.component.html',
  styleUrls: ['./solution-edit.component.scss']
})
export class SolutionEditComponent {

  @Input() selectedSolution: Solution;
  @Input() private solutionForm: FormGroup;
  @Input() editMode = false;
  constructor(private solutionsService: SolutionsService, private alertService: AlertService, private gitLabService: GitLabService) {
  }
  onSubmit() {
    if (this.editMode && this.selectedSolution) {
      this.solutionForm.enable();
      this.solutionsService.updateSolution(this.solutionForm.value).subscribe((idSolution) => {
        this.editMode = false;
        this.downLoadFile(this.solutionForm.value);
        this.alertService.success('Success!!');
      },
        (error) => {
          this.alertService.error(error.error.message);
        });
    } else if (!this.selectedSolution) {
      this.solutionsService.addSolution(this.solutionForm.value).subscribe((idSolution) => {
        this.downLoadFile(this.solutionForm.value);
        this.alertService.success('Success!!');
      },
        (error) => {
          this.alertService.error(error.error.message);
        });
    }

    this.editMode = false;
    this.selectedSolution = null;

  }

  private updateSolution() {
    this.editMode = true;
    this.solutionForm.enable();
    this.solutionForm.get('id').disable();
  }

  private onDeleteSolution(idSolution) {
    this.solutionsService.removeSolution(idSolution).subscribe(solution => {
      this.selectedSolution = null;
      this.alertService.success('Success!!');
    },
      (error) => {
        this.alertService.error(error.error.message);
      });
  }

  downLoadFile(solution: Solution) {
    this.solutionsService.downLoadFile(solution).subscribe(solutionId => {
      const startingGilab = this.initUserbuild(solution.label);
      this.gitLabService.startingGilabPush(startingGilab).subscribe(data => {
      });
    },
      (error) => {
        this.alertService.error(error.error.message);
      });
  }

  private initUserbuild(solutionLabel: string): StartingPush {
    return {
      branch: 'puc-development',
      // tslint:disable-next-line:max-line-length
      remote: 'https://CSAPTTP10SOPUGIT0%40zgie.ztech:mhmS8ufWObUfzDT84LQB@scm.saas.cagip.group.gca/beca1701/ros-engine.git',
      message: {
        author: 'IBOUROIHIM loutfi',
        commit: `Added rules => ${solutionLabel}`
      }
    };
  }
}
