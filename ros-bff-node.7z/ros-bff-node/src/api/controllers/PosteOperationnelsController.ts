/**
 * Controller for posteOperationnel
 */
import * as Promise from 'bluebird';
import { provideSingleton, inject } from '../../ioc/ioc';
import { Get, Route, Post, Delete, Put, Body, Tags } from 'tsoa';
import { Cr } from '../models/CR';
import { PosteOperationnelsService } from '../services/PosteOperationnelService';

@Route('posteoperationnels')
@Tags('posteoperationnels')
@provideSingleton(PosteOperationnelsController)
export class PosteOperationnelsController {

    @inject(PosteOperationnelsService)
    private posteOperationnelsService: PosteOperationnelsService;

    /**
     * Get list of posteOperationnel
     */
    @Get()
    public getPosteOperationnels(): Promise<Cr[]> {
        return this.posteOperationnelsService.getPosteOperationnels();
    }

    /**
     * Get a specific posteOperationnel
     */
    @Get('/{id}')
    public getPosteOperationnel(id: string): Promise<Cr> {
        return this.posteOperationnelsService.getPosteOperationnel(id);
    }

    /**
     * Add a posteOperationnel
     */
    @Post()
    public addPosteOperationnel(@Body() cr: Cr): Promise<Cr> {
        console.log('POST => ', cr);
        return this.posteOperationnelsService.addPosteOperationnel(cr);
    }

    /**
     * Update a posteOperationnel
     */
    @Put('/{id}')
    public updateCr(id: string, @Body() cr: Cr): Promise<Cr> {
        return this.posteOperationnelsService.updatePosteOperationnel(id, cr);
    }

    /**
     * Delete a specific posteOperationnel
     */
    @Delete('/{id}')
    public removePosteOperationnel(id: string): Promise<Cr> {
        return this.posteOperationnelsService.removePosteOperationnel(id);
    }
}
