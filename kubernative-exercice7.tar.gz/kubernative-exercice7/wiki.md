# Lien utile du wiki CAGIP pour l'exercice7

### Gestion des logs ELISA
[https://wiki.sws.group.gca/display/CCDH/Gestion+des+logs+ELISA](https://wiki.sws.group.gca/display/CCDH/Gestion+des+logs+ELISA)

### Accès aux logs ELISA
[https://wiki.sws.group.gca/pages/viewpage.action?pageId=17989702](https://wiki.sws.group.gca/pages/viewpage.action?pageId=17989702)