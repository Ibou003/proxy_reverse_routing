# Solution

### Etape 1 : Mise en place de l'arborescence Kustomize

A la racine, mettre en place l'arboresence suivante : 
```
kustomize
|->base
|->overlays
 |->dev
```

Le dossier **base** contient les fichiers yaml transverses à l'ensemble des environnements.  
Le dossier **overlays** contient un dossier par environement qui eux même contiennent les fichiers yaml spécifiques à l'environement.  

Dans les dossiers base et overlays/dev, créer un fichier **kustomization.yml**  
Déplacer les fichiers du dossier **yml** dans **kustomize/base**  

### Etape 2 : Construction du kustomization de base

Dans **kustomize/base**, editer le fichier **kustomization.yml**  
```yaml
apiVersion: kustomize.config.k8s.io/v1beta1
kind: Kustomization

resources:
- deployment.yml
- ingress.yml
- service.yml
```

Dans cette version initiale (qui evoluera, nous le verrons plus tard) nous ne définissons seulement les fichiers yaml qui seront ajoutés au manifest.  

### Etape 3 : Construction du kustomization de l'overlay

Dans **kustomize/overlays/dev** editer le fichier **kustomization.yml**  
```yaml
apiVersion: kustomize.config.k8s.io/v1beta1
kind: Kustomization

resources:
- ../../base
```

Dans cette version initiale, nous ne définissons que l'emplacement du fichier kustomize de base qui sera appelé pour ajouter au manifest les fichiers communs à l'ensemble des environements.  
Si on avait des fichiers spécifiques à la dev (qui n'est pas le cas actuellement), c'est ici qu'on les ajouterai.  

### Etape 4 : Définition du name préfix

On souhaite préfixer l'ensemble de nos objets par une chaine.
Cette fonctionnalité permet de cloisonner plusieurs environements dans un même namespace (ce qui est notre cas étant donné que l'on a un environnement par formé)  
Cela se fait en plusieurs étapes :  
Dans un premier temps, editer le fichier **kustomization.yml** dans **kustomize/overlays/dev**  
```yaml
apiVersion: kustomize.config.k8s.io/v1beta1
kind: Kustomization
namePrefix: {{environement utilisateur}}-
```
On ajoute la ligne **namePrefix** après l'entête.  

Cette ligne va ajouter le préfixe défini au nom de l'ensemble des objets kube définis dans les fichier descritifs de déploiement.  
Cependant, par defaut kustomize ne change que le nom des objets.   
Hors nous disposons dans nos fichier de **label** et **labelSelector**. Si nous ne mettons pas à jour ce champs, les environnements pointerons les uns sur les autres.
Kustomize propose une solution pour ce cas.
Créer un fichier **namePrefix.yml** dans le répertoire **kustomize/overlays/dev** et l'éditer
```yaml
namePrefix:
- path: metadata/name

- kind: Deployment
  group: apps
  path: spec/selector/matchLabels/app
  version: v1

- kind: Deployment
  group: apps
  path: spec/template/metadata/labels/app
  version: v1

- kind: Service
  version: v1
  path: spec/selector/app
```
Dans ce fichier, nous indiquons l'ensemble des champs devant être mis à jour.  
Il suffit ensuite d'indiquer à kustomize de prendre en compte ce nouveau fichier.  

Dans **kustomize/overlays/dev** , ajouter dans **kustomization.yml**  
```yaml
configurations:
- nameprefix.yml
```

Il reste un point que la manipulation précédente ne corrige pas : les hosts de l'ingress ne peuvent être mis à jour par la méthode précédente.
Il va falloir utiliser un moyen détourné.
Dans le fichier **kustomization.yaml** de **kustomize/base** ajouter : 
```yaml
vars:
- name: DEP_NAME
  objref:
    kind: Deployment
    name: hello
    apiVersion: apps/v1
```
Nous definissons ici une variable qui portera le nom de notre deployment (qui sera lui préfixé).

Mettons à jour les hosts dans notre ingress : 
```yaml
apiVersion: extensions/v1beta1
kind: Ingress
metadata:
  name: hello-ingress

spec:
  rules:
  - host: $(DEP_NAME).devops.caas.cagip.group.gca 
    http:
      paths:
      - backend:
          serviceName: hello-service
          servicePort: 8080
  tls:
  - hosts:
    - $(DEP_NAME).devops.caas.cagip.group.gca 

``` 
Nous avons modifié les hosts en y incluant la variable précédemment créée qui elle même est préfixée, nous avons donc maintenant des hosts préfixés.


### Etape 5 : Construction du manifest

Notre architecture kustomize est maintenant prête à l'utilisation.  
Pour générer le fichier manifest, il suffit de lancer la commande (depuis le répertoire kustomize) :  
*kustomize build overlays/dev/ > manifest.yml*

Il suffit ensuite de lancer un apply avec ce fichier :  
*kubectl apply -f manifest.yml*

### Etape 6 : Nettoyage

Un autre avantage de kustomize, est la facilité à la supression d'une infra complète :  
*kubectl delete -f manifest.yml*