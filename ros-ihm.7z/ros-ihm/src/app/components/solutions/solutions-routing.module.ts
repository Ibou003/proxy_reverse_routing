import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SolutionsListComponent } from './solutions-list/solutions-list.component';

const solutionRoutes: Routes = [
  {
    path: '',
    component: SolutionsListComponent,
  }
];

@NgModule({
  imports: [
    RouterModule.forChild(solutionRoutes)
  ],
  exports: [RouterModule]
})
export class SolutionsRoutingModule { }
