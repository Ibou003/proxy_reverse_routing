import { EventEmitter, Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';

@Injectable()
export class SharedService {

    public userConnectedEvent = new EventEmitter<boolean>();
    public menuItemEvent = new EventEmitter<string>();

    constructor() {
     }

    onUserConnected(userLoggedIn: boolean): Observable<void> {
      this.userConnectedEvent.emit(userLoggedIn);
      return of();
    }

    onMenuItemSelected(menuItem: string): Observable<void> {
      this.menuItemEvent.emit(menuItem);
      return of();
    }
}
