import * as Promise from 'bluebird';
import { provideSingleton } from '../../ioc/ioc';
import * as _ from 'lodash';
import * as simplegit from 'simple-git/promise';
import * as shellJs from 'shelljs';
import { Message, StartingPush } from '../models/GitLab';
shellJs.cd('ros-engine');
@provideSingleton(GitLabService)
export class GitLabService {

    private git = simplegit();

    constructor() {
        this.git.addConfig('user.email', 'Loutfi.IBOUROIHIM-ext@ca-ts.fr');
        this.git.addConfig('user.name', 'Ibouroihim Loutfi');
    }

    gitLabClone(remote: string): Promise<string> {
        return this.git.silent(true).clone(remote).catch(err => console.error(err)
        );
    }

    gitLabAdd(): Promise<string> {
        return this.git.silent(true).add('.');
    }

    gitLabCommit(message: Message): Promise<Message> {
        return this.git.commit(message.commit);
    }

    gitLabPull(): Promise<string> {
        return this.git.pull();
    }

    gitLabPush(): Promise<string> {
        return this.git.silent(true).push().catch(err => console.error(err)
        );
    }

    gitLabCheckout(branch: string): Promise<string> {
        return this.git.silent(true).checkout(branch);
    }

    gitLabBranchLocal(): Promise<string> {
        return this.git.silent(true).branchLocal();
    }

    startingGilabPush(startingPush: StartingPush): Promise<string> {
        this.gitLabCheckout(startingPush.branch).then(checkout => {
            this.gitLabPull().then(pull => {
                this.gitLabAdd().then(add => {
                    this.gitLabCommit(startingPush.message).then(commit => {
                        return this.gitLabPush();
                    });
                });
            });
        }
        );
    }
}
