# Liens utiles du wiki CAGIP pour l'exercice3

### Accès à l'outil ArgoCD
[https://wiki.sws.group.gca/pages/viewpage.action?pageId=17989681](https://wiki.sws.group.gca/pages/viewpage.action?pageId=17989681)

### CD avec ArgoCD
[https://wiki.sws.group.gca/display/CCDH/2.+CD+avec+ArgoCD](https://wiki.sws.group.gca/display/CCDH/2.+CD+avec+ArgoCD)

### Génération d'un deploy token
[https://wiki.sws.group.gca/pages/viewpage.action?pageId=17993019](https://wiki.sws.group.gca/pages/viewpage.action?pageId=17993019)