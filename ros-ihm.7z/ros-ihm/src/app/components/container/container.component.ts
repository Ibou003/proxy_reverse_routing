import { Component, OnInit } from '@angular/core';
import Constants from '../../../const';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/services/auth.service';
import { SharedService } from 'src/app/services/shared.service';

@Component({
  selector: 'app-container',
  templateUrl: './container.component.html',
  styleUrls: ['./container.component.scss']
})
export class ContainerComponent implements OnInit {

  userLoggedIn = false;
  loginAction = Constants.LABELS.ACTIONS.LOGIN;
  activeMenu = Constants.MENUS.HOME;
  constructor(
      private router: Router
    ) { }

  ngOnInit() {
    this.selectMenuItem();
  }

  selectMenuItem() {
    this.activeMenu = this.router.url.split('/')[1];
  }

  onMenuItemClicked(menuItem) {
    this.activeMenu = menuItem;
  }

}
