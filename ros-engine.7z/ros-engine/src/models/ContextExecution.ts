export interface ContextExecutions {
    systemInfo?: {
        uid?: string;
        id?: string;
        operationalPost?: {
            uid?: string,
            id?: string   ,
            label?: string,
            type?: string,
            mediaType?: string,
            deviceType?: string,
            ip?: string,
            hostname?: string,
            printerPeripherals?: []
        },
        eds?: {
            id?: string,
            label?: string,
            idexelst?: string
        },
        financialTransactionDate?: string
    };
    sessionMode?: {
        uid?: string,
        id?: string,
        idSessionPortail?: string,
        canal?: string,
        distribCanal?: string,
        transport?: string,
        usage?: string,
        nomad?: string
    };
    profile?: {
        uid?: string,
        id?: string,
        functionalPost?: {
            id?: string,
            label?: string,
            functionId?: string,
            functionLabel?: string,
            edsId?: string
        },
        user?: {
            uid?: string,
            id?: string ,
            code?: string,
            type?: string,
            lastName?: string,
            firstName?: string
        },
        customerRole?: {
        uid?: string,
        id?: string,
        markets?: [],
        segments?: []
    },
        structureId?: string,
        bankNetwork?: string,
        camEntity?: string,
        inversedCAMEntity?: string
    };
}

export class ContextExecution implements ContextExecutions {
    constructor(structureId: string, eds: string, operationalPost: string) {
        return {
            systemInfo: {
                eds: {
                    id : eds
                },
                operationalPost: {
                    id : operationalPost
                }
            },
            profile: {
                structureId: structureId
            }
        };
    }
}