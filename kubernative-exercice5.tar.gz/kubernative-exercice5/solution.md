# Solution

### Etape 1 : Création du secret das Vault

Se connecter à **Vault**.  
Aller dans *secret/devops/formation_te/k8s/development/*  
Cliquer sur **Create secret**  
Il s'agit ici de la création d'un catalogue de secrets.  
Il peut en effet être utile de créer différents catalogues pour différentes briques techniques ou logiques (ici votre catalogue portera votre nom/trigramme/...).  
Renseigner vos paires clé/valeur (*secret_hello*/*Valeur_secret*).  
Pour ajouter un nouveau secret, il suffit de cliquer sur le bouton Add en bout de ligne.  
Cliquer sur **Save**.  


### Etape 2 : Récupération du secret dans kube

Il faut dans un premier temps créer un objet VaultSecret qui représentera votre catalogue créé dans vault.  
Créer le fichier **secret.yml**  
```yaml
apiVersion: ca-gip.github.com/v1
kind: VaultSecret
metadata:
  name: hello-secret
spec:
  secretname: hello-secret-cata
  secretpath: secret/data/devops/formation_te/k8s/development//{{nom du catalogue}}
  version: "1"
```

Il suffit ensuite de rendre disponible le secret dans le pod. Modifier le fichier **deployment.yml** : 
```yaml
      name: hello
      env:
        - name: SECRET_HELLO
          valueFrom:
            secretKeyRef:
              name: hello-secret-cata
              key: secret_hello
	  imagePullPolicy: Always
```

### Etape 3 : Afficher la valeur dans l'applicatif.
Le secret est mis à disposition dans le docker sous forme de variable d'environement, il suffit juste de la récupérer et de l'afficher.
```python
    msg = 'Hello '+os.environ['SECRET_HELLO']
```

Et d'ajouter les librairies associés à os, à mettre en entete du main.py 
```python
    from BaseHTTPServer import BaseHTTPRequestHandler,HTTPServer
    import os
    import urllib2
    import ssl
```

Il faut bien entendu rebuilder l'image, la remonter sur artifactory et modifier le **deployment.yml** pour prendre en compte cette nouvelle image (cf exercice 1).  


### Etape 4 : Deploiement

Plusieurs solutions s'offrent à vous après avoir recréé le manifest : 
- ArgoCD (si vous avez effectué les exercices précédent et que votre environnement ArgoCD marche)
- Manuellement (si vous faites cet exercice de manière isolée)