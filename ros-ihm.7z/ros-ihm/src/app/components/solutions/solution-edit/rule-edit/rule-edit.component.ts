import { Component, Input } from '@angular/core';
import { FormGroup, FormControl, FormArray, Validators } from '@angular/forms';

@Component({
  selector: 'app-rule-edit',
  templateUrl: './rule-edit.component.html',
  styleUrls: ['./rule-edit.component.scss']
})
export class RuleEditComponent {
  @Input() ruleForm: FormGroup;
  @Input() editMode = false;
  onEditItem(item: string) {
    (this.ruleForm.get(item) as FormArray).push(
      new FormGroup({
        id: new FormControl(null, Validators.required),
        serviceName: new FormControl(null, Validators.required)
      })
    );
  }
  onDeleteItemIndex(index: any, item): any {
    (this.ruleForm.get(item) as FormArray).removeAt(index);
  }
  getCRS() {
    return this.ruleForm.get('crs') as FormArray;
  }

  getPosteOp() {
    return this.ruleForm.get('posteOp') as FormArray;
  }
  getEDS() {
    return this.ruleForm.get('eds') as FormArray;
  }

}
