
const constants = {
    HTTP: {
        RESPONSE: {
            STATUS: {
                BAD_REQUEST: {
                    CODE: 400,
                    MESSAGE: 'Bad request, front issue'
                },
                INTERNAL_ERROR: {
                    CODE: 500,
                    MESSAGE: 'Internal server error'
                },
                NOT_ALLOWED: {
                    CODE: 403,
                    MESSAGE: 'You\'re a not allowed to access this resource'
                },
                NOT_FOUND: {
                    CODE: 404,
                    MESSAGE: 'Resource not found'
                },
                UNAUTHORIZED: {
                    CODE: 401,
                    MESSAGE: 'Invalid credentials or session token'
                },
                SESSION_EXPIRED: {
                    CODE: 401,
                    MESSAGE: 'Session expired'
                }
            }
        }
    },
    RULES: {
        ID: 'id',
        SERVICE: 'serviceName',
        LABEL: 'label',
        CONTEXT_EXECUTION: 'contextexecution'
    }
};

export default constants;
