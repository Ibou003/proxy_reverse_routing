const constants = {
    ROUTES: {
        PATHS: {
            LOGIN: '/login'
        }
    },
    MENUS: {
        HOME: 'home'
    },
    LABELS: {
        ACTIONS: {
            LOGIN: 'Connexion',
            LOGOUT: 'Déconnexion'
        }
    },
    WEEK_DAYS: [
        {
            day_of_week: '1',
            label: 'Lundi'
        },
        {
            day_of_week: '2',
            label: 'Mardi'
        },
        {
            day_of_week: '3',
            label: 'Mercredi'
        },
        {
            day_of_week: '4',
            label: 'Jeudi'
        },
        {
            day_of_week: '5',
            label: 'Vendredi'
        },
        {
            day_of_week: '6',
            label: 'Samedi'
        },
        {
            day_of_week: '7',
            label: 'Dimanche'
        }
    ]
};
export default constants;
