# Exercice 2

### Avant propos
Vous serez plusieurs formés à travailler sur le même namespace, pensez à spécifier vos noms et labels afin de ne pas vous marcher sur les pieds.

### Etat initial
Sont disponibles : 
- Dans **src** le source de l'application
- **Dockerfile** pour la construction de l'image
- Dans **yml**, l'ensemble des fichiers de déploiement de l'application.

### But de l'exercice
Dans cet exercice, vous devrez mettre en place kustomize pour : 
- gerer différents environements (seulement la dev dans cet exercice)
- prefixer vos objets kube
- isoler complètement votre environement (il y aura un environement par formé dans le namespace)
- générer un fichier manifest permettant le déploiement de l'application par un fichier unique 

### Marche à suivre
Vous pouvez, soit effectuer la mise en place par vous même, soit suivre la procédure mise à disposition dans le fichier [solution.md](solution.md).  
Quoi qu'il en soit, vous aurez besoin des informations suivantes :

- Pour vous connecter à kubi :  
kubi.devops.managed.cagip.group.gca

- namespace de formation :  
formation-te-development

A la fin de l'exercice, merci de penser à nettoyer les objets kube créés sur le namespace de formation.