# Solution

### Etape 1 : Création de l'image
L'image est créée via un dockerfile :  
*Créer un fichier **Dockerfile** à la racine du projet*

```
FROM python:2.7-alpine3.9

# Création du repertoir app à la racine de l'image dans lequel seront mis les sources
RUN mkdir /app
# Copie du source main.py depuis le répertoire local src vers le répertoire de l'image précédemment créé
COPY src/main.py /app/

# Par defaut, l'applicatif est lancé en root
# La bonne pratique est de réduire au maximum les droits de l'utilisateur avec lequel sera lancé l'applicatif
# Dans notre cas, on utilisera l'utilisateur nobody
# On applique les droits en lecture au répertoire app et à son contenu
RUN chmod -R 500 /app/
# On associe le répertoire app et son contenu à l'utilisateur nobody
RUN chown -R nobody:nobody /app/
#on indique que la suite des executions se feront en tant que nobody
USER nobody

# Au lancement de l'image, la commande pyton sera lancée par défaut
CMD python /app/main.py
```

Une fois le dockerfile créé, il ne reste plus qu'à créer l'image via la command **docker build**  
Format : *docker build -t **{{repo}}/{{environement utilisateur}}/{{nom de l'image}}:{{tag}}** .*  
Le . correspond au répertoire où se situe le Dockerfile (ici on part du principe qu'il s'agit du répertoire courant)  
Lancer la commande :  
*docker build . -t cagip-formation-te-docker-scratch-intranet.registry.saas.cagip.gca/**{{environement utilisateur}}**/hello:1 .*  

Il suffit ensuite de pousser l'image dans artifactory :  
- D'abord en se connectant :  
*docker login cagip-formation-te-docker-scratch-intranet.registry.saas.cagip.gca*  
- Puis en poussant l'image :  
*docker push cagip-formation-te-docker-scratch-intranet.registry.saas.cagip.gca/**{{environement utilisateur}}**/hello:1*  

Vous pouvez aller vérifier que votre image a bien été poussée en vous connectant à :  
[https://registry.saas.cagip.gca/](https://registry.saas.cagip.gca/)  
(Puis dans **Artifacts**, deuxième onglet dans la barre de gauche)  

### Etape 2 : Création du deployment

La brique de base contenant notre applicatif est le pod, et par extension (pour la gestion de son cycle de vie) un deployment.  
Dans un répertoire **yml** créé à la racine du projet, créer un fichier **deployment.yml**  

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: hello-**{{environement utilisateur}}**
spec:
  replicas: 1
  selector:
    matchLabels:
      app: hello-**{{environement utilisateur}}**
  template:
    metadata:
      labels:
        app: hello-**{{environement utilisateur}}**
    spec:
      imagePullSecrets:
       - name: project-registries
      containers:
      - image: cagip-formation-te-docker-scratch-intranet.registry.saas.cagip.gca/**{{environement utilisateur}}**/hello:1
        name: hello-**{{environement utilisateur}}**
        imagePullPolicy: Always
        ports:
          - name: http
            containerPort: 8080
            protocol: TCP
        resources:
          limits:
            memory: "512Mi"
          requests:
            memory: "512Mi"
            cpu: "800m"
```

Les spécificité *kubernative* dans ce déploiement sont :  
```yaml
    spec:
      imagePullSecrets:
       - name: project-registries
```
Ce morceau permet à kube de récupérer les identifiant lui permettant de se connecter à artifactory.  
Le pull anonyme n'est pas possible.

```yaml
        resources:
          limits:
            memory: "512Mi"
          requests:
            memory: "512Mi"
            cpu: "800m"
```
Dans l'environement kubernative, la limite mémoire et les prérequis memoire et cpu sont obligatoires.

### Etape 3 : Création du service

Le service permet aux autres briques kube (dans notre cas l'ingress que l'on verra dans l'étape suivante) de retrouver nos pods.  
Dans le répertoire **yml**, créer le fichier **service.yml**  
```yaml
apiVersion: v1
kind: Service
metadata:
  name: hello-**{{environement utilisateur}}**-service

spec:
  type: ClusterIP
  ports:
  - name: http
    port: 8080
    targetPort: 8080
  selector:
    app: hello-**{{environement utilisateur}}**
```

Rien de spécifique à kubernative dans la création du service.

### Etape 4 : Création de l'ingress

L'ingress va permettre de gérer les flux entrant et de les rediriger vers nos pods (service en fait).  
Il agit comme un revers proxy.  
Dans le répertoire **yml**, créer le fichier **ingress.yml**  
```yaml
apiVersion: extensions/v1beta1
kind: Ingress
metadata:
  name: hello-{{environement utilisateur}}-ingress

spec:
  rules:
  - host: hello-{{environement utilisateur}}.devops.caas.cagip.group.gca 
    http:
      paths:
      - backend:
          serviceName: hello-{{environement utilisateur}}-service
          servicePort: 8080
  tls:
  - hosts:
    - hello-{{environement utilisateur}}.devops.caas.cagip.group.gca 
```

Aucune spécificité kubernative dans la création de l'ingress.  

### Etape 5 : Création des objets kube

Maintenant que les fichiers yaml de création de notre environement sont prêts, nous allons pouvoir deployer notre application.  
Dans un premier temps, il faut se connecter au cluster (à l'aide de **kubi**) :  
*kubi --kubi-url kubi.devops.managed.cagip.group.gca --username **{{username}}** --generate-config*  
Ensuite, pointez vers le namespace adequate (permettra d'éviter de préciser le namespace à chaque commande) :  
*kubectl config set-context $(kubectl config current-context) --namespace formation-te-development*  

Nous pouvons maintenant déployer notre application :  
*kubectl deploy -f yml/deployment.yml*  
*kubectl deploy -f yml/service.yml*  
*kubectl deploy -f yml/ingress.yml*  

Verifiez que tous sont déployés correctement à l'aide des commandes :  
*kubectl get po*  
*kubectl get deployment*  
*kubectl get svc*  
*kubectl get ingress*  

L'application devrait alors être disponible à l'adresse :  
https://hello-**{{environement utilisateur}}**.hors-prod.caas.ca-cf.gca  

### Etape 6 : Nettoyage

Il ne reste plus qu'à supprimer ce qui a été créé :  
*kubectl delete deployment hello-**{{environement utilisateur}}** *  
*kubectl delete svc hello-**{{environement utilisateur}}**-service*  
*kubectl delete ingress hello-**{{environement utilisateur}}**-ingress*  
