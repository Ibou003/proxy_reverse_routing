export const environment = {
  production: true,
  API_BASE_PATH: 'http://localhost:8080/api'
};
