# Solution

### Etape 1 : Configuration du projet Manifest

En dehors du projet courrant, créer un projet manifest :  
*git clone https://scm.saas.cagip.group.gca/formation/manifests.git*

Créer une branche à votre nom :  
*git checkout -b {{nom de la branche}}*

Faire un push pour remonter la création de votre branche dans le GitLab :  
*git push*

Créer un répertoire dev :  
*mkdir dev*

Y déposer le fichier manifest créé lors de l'exercice précédent.  

Remonter le fichier sur git :  
*git add dev/manifest.yml*  
*git commit -m "première version du manifest*  
*git push --set-upstream origin {{nom de la branche}}*  

### Etape 2 : Création du projet ArgoCD

Se connecter à [ArgoCD](https://cd.devops.caas.cagip.group.gca/).  

Cliquer sur le bouton **New Application**

Renseigner les champs de la manière suivante : 
**General**  
- Application name : *{{Nom de l'application}}  
Il s'agit du nom de votre application au sens ArgoCD  
- Project : *formation-te-development*  
Correspond au namespace sur lequel vous souhaitez déployer  
- Sync-Policy : Manual  
Indique si vous voulez qu'argoCD scrute votre manifest afin de mettre à jour votre projet si celui-ci change.  

**Source**  
- Repository URL : *https://scm.saas.cagip.group.gca/formation/manifests.git*  
Correspond au repository sur lequel est publié votre manifest.  
- Revision : *{{nom de votre branche}}*  
Branche du git sur laquelle vous souhaitez récupérer le manifest  
- path : *dev/*  
Chemin du manifest sur le git

**Destination**  
- Cluster URL : *https://kubernetes.default.svc*  
Seul default est disponible dans la configuration Factory (il pointe vers le cluster mutualisé ici)  
- Namespace : *formation-te-development*  
namespace sur lequel vous souhaitez déployer

Laiser le dernier champs sur *Directory* puis Cliquer sur le bouton **Create**

Une fois de retour à l'accueuil, cliquez sur votre projet, vous pourrez voir votre projet en cours de déploiement/déployé.

Vous pouvez vous amuser à changer le nombre de réplicas de votre objet Deployment, de remonter le manifest dans git et d'actualiser votre projet ArgoCD.

### Infos complémentaires

Dans le cas de la formation, toute la configuration est faite, mais vous pouvez aller jeter un oeil (Dans le menu gauche, deuxième bouton).

Il y a trois sous menus : 
- Repository : définition des repos git où ArgoCD peut récupérer les manifests
- Clusters : liste des clusters sur lesquels ArgoCD peut déployer (renseigné automatiquement lors de l'installation d'ArgoCD)
- Projects : liste des namespaces disponible pour cette instance ArgoCD et sur lesquels l'utilisateur a des droits (renseigné automatiquement lors de l'installation d'ArgoCD)

Pour ce qui est de la Sync-Policy, il existe deux écoles : 
- Auto-sync  
Dans ce cas, il suffit de pousser le manifest dans git, ArgoCD repère tout seul qu'il y a eu des changements et met à jour l'environement (avec une certaine latence)
- Manual  
Dans ce cas il faut indiquer à ArgoCD via appel CLI ou API la nécessité de se synchroniser avec le manifest (à mettre en place au niveau de la CD). Plus de travail mais plus réactif.

A noter que la CLI/API Argo CD permettent d'effectuer toute sortes d'actions (dont la création/supression de projets (modulo les droits donnés au token dispo sur votre projet))  
[Plus de détails ici](https://cd.devops.caas.cagip.group.gca/help)