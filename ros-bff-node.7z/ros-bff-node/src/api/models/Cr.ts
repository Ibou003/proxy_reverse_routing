export interface Cr {
    id: string;
    label: string;
}
