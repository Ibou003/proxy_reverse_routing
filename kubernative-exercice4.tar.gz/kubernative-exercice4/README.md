# Exercice 4

### Avant propos
Vous serez plusieurs formés à travailler sur le même namespace, pensez à spécifier vos noms et labels afin de ne pas vous marcher sur les pieds.

### Etat initial
Sont disponibles :
- Dans **src** le source de l'application
- **Dockerfile** pour la construction de l'image
- Dans **kustomize**, l'ensemble des fichiers de déploiement de l'application au format kustomize.

### But de l'exercice
Le but de cet exercice est de vous confronter à Xray. Pas de solution ici

### Marche à suivre
Si vous ouvrez le **Dockerfile**, vous pourrez voir que l'image de base a été changée : *node:6-stretch*  
Cette image de base va nous remonter un *certain nombre* de soucis de sécurité.  
Buildez l'image en la tagant selon votre bon vouloir (un tag permettant tout de même d'expliciter qu'il s'agit d'un image non utilisable, même si nous la supprimerons ensuite).  
Connectez vous sur [Artifactory](https://registry.saas.cagip.gca/) .  
Dans le menu gauche, cliquez sur Artifacts (deuxième icône) puis chercher votre image nouvellement créée.  
Déployer jusqu'à trouver le *manifest.json*.  
Cliquer sur l'onglet **Xray**.  
Cliquer sur **More Details In Xray**  
Vous voilà dans **Xray**.

Si vous cliquez sur une alerte, vous aurez les informations intéressantes suivantes dans la partie gauche : 
- **Fixed verion** : version de la librairie en cause dans laquelle le problème est corrigé (information disponible aussi dans le champs **Versions**)
- **Summary** : un résumé du problème
- **Severity** : Trois niveaux possible - *High*, *Medium*, *Low*. Seul les highs bloquent le promote en stable.
- **CVE** : nom de la CVE liée au problème (pour plus de détail)
- **Reference** lien(s) pour plus de détails
 

Pensez à supprimer votre image une fois terminé.