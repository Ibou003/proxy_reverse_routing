import { provideSingleton } from '../../ioc/ioc';
import { Service } from './Service';
import { logger } from '../../common/log/Logger';

@provideSingleton(VersionService)
export class VersionService extends Service {

    public getVersion(): string {
        const version = process.env.VERSION || 'unknown';
        logger.log('info', `Application version is: ${version}`);
        return version;
   }

   public postVersion(body: any): any {
    logger.log('info', `Request body is: ${JSON.stringify(body)}`);
    return body;
}
}
