# Exercice 3

### Avant propos
Vous serez plusieurs formés à travailler sur le même namespace, pensez à spécifier vos noms et labels afin de ne pas vous marcher sur les pieds.

### Etat initial
Sont disponibles :
- Dans **src** le source de l'application
- **Dockerfile** pour la construction de l'image
- Dans **kustomize**, l'ensemble des fichier de déploiement de l'application au format kustomize.

### But de l'exercice

Le but de cet exercice est de déployer l'applicatif à l'aide d'argoCD

### Marche à suivre

Merci d'utiliser le projet [Manifests](https://scm.saas.cagip.group.gca/formation/manifests.git) comme interface avec ArgoCD.  
Créez y une branche à votre nom pour y déposer votre/vos manifest(s)

L'URL d'**ArgoCD** est :  
[https://cd.devops.caas.cagip.group.gca/](https://cd.devops.caas.cagip.group.gca/)