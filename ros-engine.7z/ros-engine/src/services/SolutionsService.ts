import * as fs from 'fs';
import * as _ from 'lodash';
import * as moment from 'moment';
import * as glob from 'glob';
import { logger } from '../utils/Logger';
import { Solution } from '../models/Solutions';
import * as schedule from 'node-schedule';

export class SolutionsService {

    private solutions: Solution[] = [];
    private solutionsTemp: Solution[] = [];
    private lastUpdateTime = null;
    private folderPath = null;

    constructor(folderPath: string) {
        logger.info(`Initialisation de la table routage`);
        this.folderPath = folderPath;
        this.initRoutingTable();
        this.schedule();
    }

    getSolutions(): Solution[] {
        return this.solutions;
    }

    private initRoutingTable() {
        // Lecture fichier semaphore
        const modificationTime = this.readSemaphore();
        logger.info(`Date de semaphore: ${moment(modificationTime).format('DD/MM/YYYY - HH:mm:ss')}`);
        logger.info(`Initialisation de la table de routage`);
        this.computeSolutions();
        if (_.isNull(modificationTime)) {
            this.lastUpdateTime = moment().startOf('year');
        } else {
            this.lastUpdateTime = modificationTime;
        }
    }

    private schedule() {
        let cron = '*/10 * * * * *';

        if (!_.isEmpty(process.env.CRON)) {
            cron = process.env.CRON;
        }
        schedule.scheduleJob(cron, () => {
            const modificationTime = this.readSemaphore();
            if (!_.isNull(modificationTime) && !this.lastUpdateTime.isSame(modificationTime)) {
                logger.info(`Nouvelle date de semaphore détectée : ${moment(modificationTime).format('DD/MM/YYYY - HH:mm:ss')}`);
                logger.info(`Recalcul de la table de routage`);
                this.computeSolutions();
                this.lastUpdateTime = modificationTime;
            }
        });
    }

    private computeSolutions() {
        try {
            const files = glob.sync(`${this.folderPath}/*.json`);
            this.solutionsTemp = [];
            files.forEach(file => {
                this.addSolution(file);
            });
            this.solutions = _.concat([], this.solutionsTemp);
            logger.info(`Nouvelle table de routage à jour`);
            logger.info(JSON.stringify(this.solutions, null, 2));
        } catch (err) {
            logger.warn(`Erreur lors du calcul de routage depuis le dossier des solutions: ${this.folderPath}.`);
            logger.warn(err);
        }
    }

    private addSolution(filePath: string) {
        let fileContent;
        if (fs.lstatSync(filePath).isFile()) {
            fileContent = fs.readFileSync(filePath);
        } else if (fs.lstatSync(filePath).isSymbolicLink()) {
            let realPath = fs.realpathSync(filePath);
            fileContent = fs.readFileSync(realPath);
        } else {
            logger.warn(`Erreur lecture fichier: ${filePath}. Ceci n'est pas un fichier`);
        }

        if (!_.isEmpty(fileContent)) {
            logger.info(`Chargement des règles de routage depuis le fichier: ${filePath}`);
            let solution: Solution = JSON.parse(fileContent.toString());
            solution.source = filePath;
            this.solutionsTemp = _.concat(this.solutionsTemp, solution);
        }
    }

    private readSemaphore(): any {
        // Lecture fichier semaphore
        const path = `${this.folderPath}/semaphore.txt`;

        try {
            fs.statSync(path);
            const semaphoreFileContent = fs.readFileSync(`${this.folderPath}/semaphore.txt`);
            const modificationTime = moment.unix(parseInt(semaphoreFileContent.toString(), 10));
            return modificationTime;
        } catch (err) {
            logger.warn(`Le fichier ${this.folderPath}/semaphore.txt n'existe pas.`);
            logger.warn('Aucune nouvelle règle ne sera chargé');
            return null;
        }
    }
}