# Solution 

## Prometheus

Le code du fichier source de l'application a été modifié pour mettre à disposition sur l'url */metrics* la valeur : 
***hello_call xx***  
où xx est le nombre d'appel du pod depuis son lancement.  

Dans un premier temps, modifier le source pour préfixer la metric par votre nom.

La marche à suivre est ensuite la suivante : 

### Etape 1 : Création du service monitor
Pour prévenir **Prométheus** qu'il doit surveiller nos pods, il faut lui créer un objet de type ServiceMonitor :

```yaml
apiVersion: monitoring.coreos.com/v1
kind: ServiceMonitor
metadata:
  name: hello-monitor
spec:
  selector:
    matchabels:
      app: hello
      type: svc
  endpoints:
    - port: http
```

### Etape 2 : Mise à jour de la config yaml

Vous remarquerez que le selector porte cette fois-ci sur le service (le précédent selector se faisait sur les pods).  
Il nous faut donc mettre à jour notre configuration yaml afin de : 
- Ajouter des labels au service
- Mettre à jour les labels existants afin de distinguer les pods et les services.

Pour celà, commeçons par mettre à jour ***deployment.yml*** : 
```yaml
  template:
    metadata:
      labels:
        app: hello
        type: pod
```
nous ajoutons le label  *type* aux labels décrivant les pods.

Puis dans le selector du deployment : 
```yaml
  selector:
    matchLabels:
      app: hello
      type: pod
```
Nous le mettons à jour afin qu'il ne prenne en compte que les pods

Ensuite dans ***service.yml*** : 
```yaml
metadata:
  name: hello-service
  labels:
    app: hello
    type: svc
```
On ajoute les labels *app* et *type*

Puis on met à jour le selector : 
```yaml
  selector:
    app: hello
    type: pod
```

Finalement, dans ***kustomization.yml*** du répertoire **base**, nous ajoutons le monitor.yml précédemment créé : 
```yaml
resources:
- deployment.yml
- ingress.yml
- service.yml
- monitor.yml
```

### Etape 3 : Déploiement de la nouvelle archi

Plusieurs solutions s'offrent à vous après avoir recréé le manifest : 
- ArgoCD (si vous avez effectué les exercices précédent et que votre environement ArgoCD marche)
- Manuellement (si vous faites cet exercice de manière isolée)

## Grafana

Le grafana fourni par la factory ne permet que la lecture des metrics remontées par le socle.  
Pour afficher des metrics applicatives, il faut déployer votre propre grafana, voilà comment faire :  

### Etape 1 : Création du déploiement grafana

Créer le fichier déploiement yaml **grfna-deployment.yml** dans **base**
```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: grfna
spec:
  replicas: 1
  selector:
    matchLabels:
      app: grfna
      type: pod
  template:
    metadata:
      labels:
        app: grfna
        type: pod
    spec:
      imagePullSecrets:
       - name: project-registries
      containers:
      - image: cagip-formation-te-docker-scratch-intranet.registry.saas.cagip.gca/grafana:base
        name: grfna
        imagePullPolicy: Always
        env:
          - name: GF_SERVER_SERVE_FROM_SUB_PATH
            value: "true"
          - name: GF_SERVER_ROOT_URL
            value: "/grafana/"
        ports:
          - name: http
            containerPort: 8080
            protocol: TCP
        resources:
          limits:
            memory: "2048Mi"
          requests:
            memory: "2048Mi"
            cpu: "800m"
```

Rien de particulier ici, ce deploiement ressemble à celui ayant été mis en place dans l'exercice 1.


### Etape 2 : Mise en place du service grafana

Créer le fichier **grfna-service.yml** dans **base**
```yaml
apiVersion: v1
kind: Service
metadata:
  name: grfna-service
  labels:
    app: grfna
    type: svc
spec:
  type: ClusterIP
  ports:
  - name: http
    port: 8080
    targetPort: 3000
  selector:
    app: grfna
    type: pod
```

Nous redirigeons le port 8080 vers le port 3000 (port par defaut de grafana)


### Etape 3 : Création de la netpol

Grafana aura besoin d'intéroger Prometheus pour récupérer les metrics.  
Nous l'interogerons via son DNS, il faut donc authoriser grafana à accéder à Prometheus.

Créer un fichier **grfna-netpol.yml** dans **base**
```yaml
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: gfna-prometheus
spec:
  podSelector:
    matchLabels:
       app: grfna
  egress:
  - to:
    - ipBlock:
        cidr: 10.56.177.0/24
    ports:
    - protocol: TCP
      port: 443
```

Nous authorisons les pods ayant pour *label* grfna à accéder aux adresses IP de type 10.56.177.* (ce qui correspond au CIDR écrit). L'ip de prométheus étant dans cette plage, Grafana devra pouvoir accéder à Prometheus.  

### Etape 4 : modifier l'ingress

Ajouter l'accès au grafana dans l'ingress 
```yaml
    http:
      paths:
      - backend:
          serviceName: hello-service
          servicePort: 8080
      - backend:
          serviceName: grfna-service
          servicePort: 8080
        path: /grafana
```

### Etape 5 : Mettre à jour kustomize

Ajouter les fichiers précédemment créé dans le fichier **kustomization.yml** de **base**


### Etape 6 : Mettre à jour l'environement

Générer votre manifest et mettez à jour votre environement avec.

### Etape 7 : Configuration du Grafana

Connectez vous à votre grafana nouvellement déployé (*admin/admin*).  
Dans le menu gauche, cliquez sur l'icone configuration (le cinquième).  
Cliquer sur le bouton **Add data source*.  
Selectionner **Prometheus**.  
Dans *URL* mettre *https://prometheus.devops.caas.cagip.group.gca/*  
Cliquer sur **Save and Test**

Dans le menu gauche, cliquer sur **Create->Dashboard**  
Puis **Add query**  
Dans *A->metrics* renseigner le nom de votre metric.  
