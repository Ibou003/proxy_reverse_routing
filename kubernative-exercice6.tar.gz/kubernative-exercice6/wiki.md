# Liens utiles du wiki CAGIP pour l'exercice6

### Accès aux métriques applicatives via promotheus
[https://wiki.sws.group.gca/pages/viewpage.action?pageId=17989704](https://wiki.sws.group.gca/pages/viewpage.action?pageId=17989704)

### Mise en place d'une ressource K8s ServiceMonitor
[https://wiki.sws.group.gca/pages/viewpage.action?pageId=17989693#id-2.Ressourcesavanc%C3%A9esdansKubernetes(netpol,vault,secrets,configmap...)-SecretVaultSecrets-VaultInt%C3%A9gration](https://wiki.sws.group.gca/pages/viewpage.action?pageId=17989693#id-2.Ressourcesavanc%C3%A9esdansKubernetes(netpol,vault,secrets,configmap...)-SecretVaultSecrets-VaultInt%C3%A9gration)