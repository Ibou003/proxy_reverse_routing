import * as Promise from 'bluebird';
import { provideSingleton } from "../../ioc/ioc";
import { User } from "../models/User";
import * as uuidv4  from 'uuid/v4';
import * as _ from 'lodash';
import { NotFoundAPIError } from '../../common/Error/NotFoundAPIError';

@provideSingleton(UsersService)
export class UsersService {

    private users: User[];

    constructor() {
        this.users = [];
    }

    public getUsers(): Promise<User[]> {
        return this.users;
    }

    public getUser(id: string): Promise<User> {
        const user: User = _.find(this.users, {id: id});

        if (!_.isEmpty(user)) {
            return user;
        } else {
            throw new NotFoundAPIError(`User with id ${id} not found`);
        }
    }

    public addUser(user: User): Promise<User> {
        // Create id and add User
        user.id = uuidv4();
        this.users.push(user);
        return user;
    }

    public updateUser(id: string, user: User): Promise<User> {
        // Check if user with id exists
        const userIndex = _.findIndex(this.users, {id: id});

        if (userIndex > -1) {
            this.users[userIndex] = user;
            return user;
        } else {
            throw new NotFoundAPIError(`User with id ${id} not found`);
        }
    }

    public removeUser(id: string): Promise<User> {
        const userRemoved: User[] = _.remove(this.users, (user) => {
            return user.id === id;
        });

        return userRemoved.length > 0 ? userRemoved[0] : null ;
    }
}
