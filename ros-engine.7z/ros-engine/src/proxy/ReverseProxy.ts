import * as _ from 'lodash';
import * as httpProxy from 'http-proxy';
import { Solution } from '../models/Solutions';
import { logger } from '../utils/Logger';
import { LogsInfo, RuleType, UserContext } from '../models/LogsInfo';
import constants from '../utils/Constants';
import { SolutionsService } from '../services/SolutionsService';
import { ContextExecutions} from '../models/ContextExecution';

export class ReverseProxy {

    private proxyServer: any;
    private solutionsService: SolutionsService;

    constructor() {
        this.proxyServer = httpProxy.createProxyServer({});
        this.proxyServer.on('error', this.onProxyError.bind(this));
    }

    loadRules(app, solutionsFolder: string) {
        logger.info('Chargement des fichier des règles de routage');
        this.solutionsService = new SolutionsService(solutionsFolder);

        app.get('/rose-engine/table', (request, response) => {
            response.status(200).send(this.solutionsService.getSolutions());
        });

        app.all('/:solution/*', (request, response) => {
            const userContext: UserContext = this.extractContextExecution(request);
            return this.routeRequest(request, response, userContext, this.solutionsService.getSolutions());
        });
    }

    routeRequest(req: any, res, userContext: UserContext, resourcesAuth: Solution[]) {
        // Récupération des informations de la requête
        const host: string = req.hostname;
        const path: string = req.path;
        const method: string = req.method;
        const resourceAuthorization = _.find(resourcesAuth, [constants.RULES.LABEL, req.params.solution]);
        const logsInfo: LogsInfo = {
            usercontext: userContext,
            inputRequest: {
                host: host,
                method: method,
                path: path,
                headers: req.headers,
                body:  req.body
            },
            outputRequest: {
                rule: RuleType.DEFAUT,
                service: '',
                url: ''
            }
        };

        // Si la solution existe »
        if (!_.isEmpty(resourceAuthorization)) {
            // Récupération des informations de la requête
            const serviceName = this.getServiceName(resourceAuthorization, userContext, logsInfo);
            const requestDeploy = `${req.protocol}://${serviceName}`;
            // logger.info('Redirection vers l\'url => ' + requestDeploy + '/' + proxyReqParams);
            if (!_.isEmpty(serviceName)) {
                req.headers.host = serviceName;
                // Redirection de la requête
                logsInfo.message = 'Redirection de la requête OK';
                logsInfo.outputRequest.url = `${requestDeploy}${path}`;
                logger.info(JSON.stringify(logsInfo, null, 2));
                this.proxyServer.web(req, res, {
                    preserveHeaderKeyCase: true,
                    secure: false,
                    target: requestDeploy
                });
            } else {
                logsInfo.message = `Aucun service trouvé dans les règles de routage pour la solution ${req.params.solution} pour ce contexte utilisateur`;
                logger.warn(JSON.stringify(logsInfo, null, 2 ));
                res.status(404).send(`Aucun service trouvé dans les règles de routage pour la solution ${req.params.solution} pour ce contexte utilisateur`);
            }
        } else {
            // erreur 404 solution non existante
            logsInfo.message = `La solution '${req.params.solution}' n'existe pas dans les règles de routage`;
            logger.warn(JSON.stringify(logsInfo, null, 2));
            res.status(404).send(`La solution '${req.params.solution}' n'existe pas dans les règles de routage`);
        }
    }
    // Fonction appelé avant l'envoi de la requête
    // récuperation du serviceName
    public getServiceName(resourceAuthorization: any, userContext: UserContext, logsInfo: LogsInfo): any {
        const crRuleServiceName = _.find(resourceAuthorization.rules.crs, [constants.RULES.ID, userContext.structureId]);
        const edsRuleServiceName = _.find(resourceAuthorization.rules.eds, [constants.RULES.ID, userContext.eds]);
        const posteOpRuleServiceName = _.find(resourceAuthorization.rules.posteOp, [constants.RULES.ID, userContext.operationalPost]);
        const defaultRuleServiceName = resourceAuthorization.rules.defaultServiceName;
        // la CR renseigné dans le header de ma requête est présente dans les règles de routage « solution»= notre solution »
        if (!_.isEmpty(crRuleServiceName)) {
            logsInfo.outputRequest.rule = RuleType.CR;
            logsInfo.outputRequest.service = crRuleServiceName.serviceName;
            return `${crRuleServiceName.serviceName}`;
            // la l’EDS renseigné dans le header de ma requête est présente dans la règle de routage « solution= notre solution »
        } else if (!_.isEmpty(edsRuleServiceName)) {
            logsInfo.outputRequest.rule = RuleType.EDS;
            logsInfo.outputRequest.service = edsRuleServiceName.serviceName;
            return `${edsRuleServiceName.serviceName}`;
            // le poste opérationnel renseigné dans le header de ma requête est présente dans la règle de routage « solution= notre solution »
        } else if (!_.isEmpty(posteOpRuleServiceName)) {
            logsInfo.outputRequest.rule = RuleType.POSTOP;
            logsInfo.outputRequest.service = posteOpRuleServiceName.serviceName;
            return `${posteOpRuleServiceName.serviceName}`;
            // je route vers le service current
        } else {
            logsInfo.outputRequest.rule = RuleType.DEFAUT;
            logsInfo.outputRequest.service = defaultRuleServiceName;
            return `${defaultRuleServiceName}`;
        }
    }

    private onProxyError(err, req, res) {
        res.writeHead(500, {
            'Content-Type': 'text/plain'
        });
        logger.log('error', 'Une erreur est intervenue lors du routage de la requête => ' + err);
        res.end('Une erreur est intervenue lors du routage de la requête => ' + err);
    }

    private extractContextExecution(request: any): UserContext {
        // Test if there is a header contextExecution
        const contextExecution: ContextExecutions = _.has(request.headers, constants.RULES.CONTEXT_EXECUTION) ? JSON.parse(request.headers[constants.RULES.CONTEXT_EXECUTION]) : null;
        let eds = '';
        let operationalPost = '';
        let structureId = '';
        if (_.isNull(contextExecution)) {
            // No header found. Try to extract information from query params
            structureId = _.has(request.query, 'structureId') ? request.query['structureId'] : '';
            operationalPost = _.has(request.query, 'structureId') && _.has(request.query, 'hostname') ? `${request.query['structureId']}${request.query['hostname']}` : '';
        } else {
            eds = contextExecution.systemInfo.eds.id || '';
            operationalPost = contextExecution.systemInfo.operationalPost.id || '';
            structureId = contextExecution.profile.structureId || '';
        }

        const usercontext: UserContext = {
            eds: eds.trim(),
            operationalPost: operationalPost.trim(),
            structureId: structureId.trim()
        };

        return usercontext;
    }
}
