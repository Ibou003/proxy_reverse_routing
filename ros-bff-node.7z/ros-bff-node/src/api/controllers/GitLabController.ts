/**
 * Controller for Crs
 */
import * as Promise from 'bluebird';
import { provideSingleton, inject } from '../../ioc/ioc';
import { Get, Route, Tags, Post, Body } from 'tsoa';
import { GitLabService } from '../services/GitLabService';
import { Message, StartingPush } from '../models/GitLab';

@Route('git')
@Tags('git')
@provideSingleton(GitLabController)
export class GitLabController {
    private USER = 'CSAPTTP10SOPUGIT0%40zgie.ztech';
    private PASS = 'mhmS8ufWObUfzDT84LQB';
    private REPO = 'scm.saas.cagip.group.gca/beca1701/ros-engine.git';
    private remote = `https://${this.USER}:${this.PASS}@${this.REPO}`;
    @inject(GitLabService)
    private gitLabService: GitLabService;

    /**
     * Clone repo git
     */
    @Get('/clone')
    public gitLabClone(): Promise<string> {
        return this.gitLabService.gitLabClone(this.remote);
    }
    /**
     * Git add files
     */
    @Get('/add')
    public gitLabAdd(): Promise<string> {
        return this.gitLabService.gitLabAdd();
    }

    /**
     * Git commit files
     */
    @Post('/commit')
    public gitLabCommit(@Body() message: Message): Promise<string> {
        return this.gitLabService.gitLabCommit(message);
    }

    /**
     * Git checkout Branch
     */
    @Get('/checkout/{branch}')
    public gitLabCheckout(branch: string): Promise<string> {
        return this.gitLabService.gitLabCheckout(branch);
    }
    /**
     * Git pull sources
     */
    @Get('/pull')
    public gitLabPull(): Promise<string> {
        return this.gitLabService.gitLabPull();
    }

    /**
     * Git Push sources
     */
    @Get('/push')
    public gitLabPush(): Promise<string> {
        return this.gitLabService.gitLabPush();
    }
    /**
     * gets a list of local branches, calls handlerFn with two arguments, an error object and BranchSummary instance
     */
    @Get('/branchs')
    public gitLabBranchLocal(): Promise<string> {
        return this.gitLabService.gitLabBranchLocal();
    }
    @Post('/starting')
    public startingGilabPush(@Body() startingPush: StartingPush): Promise<string> {
        return this.gitLabService.startingGilabPush(startingPush);
    }
}
