export interface Session {
    id: string;
}
