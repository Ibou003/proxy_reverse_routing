import * as Promise from 'bluebird';
import { provideSingleton } from '../../ioc/ioc';
import { PosteOperationnel } from '../models/PosteOperationnel';
import * as _ from 'lodash';
import { NotFoundAPIError } from '../../common/Error/NotFoundAPIError';
import { IllegalArgumentError } from '../../common/Error/IllegalArgumentError';

@provideSingleton(PosteOperationnelsService)
export class PosteOperationnelsService {

    private posteOperationnels: PosteOperationnel[];

    constructor() {
        this.posteOperationnels = [];
    }

    public getPosteOperationnels(): Promise<PosteOperationnel[]> {
        return this.posteOperationnels;
    }

    public getPosteOperationnel(id: string): Promise<PosteOperationnel> {
        const posteOperationnel: PosteOperationnel = _.find(this.posteOperationnels, {id: id});

        if (!_.isEmpty(posteOperationnel)) {
            return posteOperationnel;
        } else {
            throw new NotFoundAPIError(`Poste Operationnel with id ${id} not found`);
        }
    }

    public addPosteOperationnel(posteOperationnel: PosteOperationnel): Promise<PosteOperationnel> {
        // check if posteOperationnel with id already exists
        const foundPosteOperationnel = _.find(this.posteOperationnels, {id: posteOperationnel.id});

        if (!_.isEmpty(foundPosteOperationnel)) {
            throw new IllegalArgumentError(`Poste Operationnel with id ${posteOperationnel.id} already exists`);
        } else {
            this.posteOperationnels.push(posteOperationnel);
            return posteOperationnel;
        }
    }

    public updatePosteOperationnel(id: string, posteOperationnel: PosteOperationnel): Promise<PosteOperationnel> {
        // Check if posteOperationnel with id exists
        const posteOperationnelIndex = _.findIndex(this.posteOperationnels, {id: id});

        if (posteOperationnelIndex > -1) {
            this.posteOperationnels[posteOperationnelIndex] = posteOperationnel;
            return posteOperationnel;
        } else {
            throw new NotFoundAPIError(`Poste Operationnel with id ${id} not found`);
        }
    }

    public removePosteOperationnel(id: string): Promise<PosteOperationnel> {
        const posteOperationnelRemoved: PosteOperationnel[] = _.remove(this.posteOperationnels, (posteOperationnel) => {
            return posteOperationnel.id === id;
        });

        return posteOperationnelRemoved.length > 0 ? posteOperationnelRemoved[0] : null ;
    }
}
